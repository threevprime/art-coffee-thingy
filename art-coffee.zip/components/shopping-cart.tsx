import { ShoppingCart } from "lucide-react"

export default function ShoppingCartIcon() {
  return <ShoppingCart className="h-5 w-5" />
}
